import { saveAs } from 'file-saver';
import ExcelJS from 'exceljs';
import { formatSchoolOwnership, formatSchoolOwnershipPreference } from './schoolDisplay';

// The print popup inherits this page's origin, so dynamic values must remain
// text rather than becoming markup in the generated document.
const escapeHtml = (value: unknown) => String(value ?? '')
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#39;');

const escapePrintData = (value: unknown): unknown => {
  if (typeof value === 'string') return escapeHtml(value);
  if (Array.isArray(value)) return value.map(escapePrintData);
  if (value && typeof value === 'object') {
    return Object.fromEntries(
      Object.entries(value as Record<string, unknown>).map(([key, child]) => [key, escapePrintData(child)]),
    );
  }
  return value;
};

export const exportTxt = (data: any, regionName: string) => {
  const content = `===============================================
               115年 會考落點分析報告                
===============================================
【基本資料】
身份: ${data.identity === 'student' ? '學生' : data.identity === 'teacher' ? '老師' : '家長'}
分析區域: ${regionName}
選取偏好: ${data.scores.schoolOwnership === 'all' ? '公私立不拘' : data.scores.schoolOwnership === 'public' ? '公立' : '私立'} / ${data.scores.schoolType === 'all' ? '普通與職業類科' : data.scores.schoolType}${data.scores.schoolType === '職業類科' && data.vocationalGroups ? ` (群別: ${data.vocationalGroups.includes('all') ? '全群別不拘' : data.vocationalGroups.join(', ')})` : ''}
產生時間: ${new Date().toLocaleString('zh-TW')}

【您的會考成績】
國文: ${data.scores.chinese}
英文: ${data.scores.english}
數學: ${data.scores.math}
自然: ${data.scores.science}
社會: ${data.scores.social}
作文: ${data.scores.composition} 級分

【積分試算結果】
您的總積分: ${data.results.totalPoints}
您的總積點: ${data.results.totalCredits || '無'}
符合條件推薦學校數: ${data.results.eligibleSchools?.length || 0} 所

===============================================
【推薦名單 (依序位推薦)】
${data.results.eligibleSchools?.map((s: any, i: number) => 
  `${String(i + 1).padStart(2, ' ')}. ${s.name} ${s.group ? `[${s.group}]` : ''} - 落點區間: ${s.zone === 'reach' ? '夢幻區' : s.zone === 'target' ? '實際區' : s.zone === 'safe' ? '保守區' : '--'} - 預估錄取門檻: ${s.minScore || s.points || s.score || '--'}`
).join('\n') || '無推薦名單'}

===============================================
【系統免責聲明】
本系統分析結果僅供參考，不代表實際錄取結果。實際錄取情況可能會因當年度招生政策變化、考生整體表現、特種身分加分、各校招生名額調整等因素而有所不同。請務必以各校最新官方發布之「免試入學招生簡章」為最終依據。
版權宣告TW全國會考落點分析 © ${new Date().getFullYear()} (我們非政府創建)
網址: ${window.location.href}
`;
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  saveAs(blob, `115年_會考落點分析_${regionName}.txt`);
};

export const exportJson = (data: any) => {
  const enhancedData = {
    metadata: {
      generatedAt: new Date().toISOString(),
      system: 'TW全國會考落點分析引擎',
      version: '1.5.0',
      sourceUrl: window.location.href,
      disclaimer: '本系統分析結果僅供參考，不代表實際錄取結果。'
    },
    userProfile: {
      identity: data.identity,
      region: data.scores.region,
      preferences: {
        ownership: formatSchoolOwnershipPreference(data.scores.schoolOwnership),
        type: data.scores.schoolType,
        vocationalGroups: data.scores.schoolType === '職業類科' ? data.vocationalGroups : undefined
      }
    },
    examScores: {
      chinese: data.scores.chinese,
      english: data.scores.english,
      math: data.scores.math,
      science: data.scores.science,
      social: data.scores.social,
      composition: parseInt(data.scores.composition) || 0
    },
    calculatedResults: {
      totalPoints: data.results.totalPoints,
      totalCredits: data.results.totalCredits || null,
      eligibleSchoolCount: data.results.eligibleSchools?.length || 0,
      recommendedSchools: data.results.eligibleSchools?.map((s: any) => ({
        name: s.name,
        type: s.type,
        ownership: formatSchoolOwnership(s.ownership),
        group: s.group || null,
        zone: s.zone === 'reach' ? '夢幻區' : s.zone === 'target' ? '實際區' : s.zone === 'safe' ? '保守區' : null,
        estimatedThreshold: s.minScore || s.points || s.score || null
      })) || []
    }
  };
  const blob = new Blob([JSON.stringify(enhancedData, null, 2)], { type: 'application/json;charset=utf-8' });
  saveAs(blob, `115年_會考落點分析_${data.scores.region}.json`);
};

export const exportExcel = async (data: any, regionName: string) => {
  const wb = new ExcelJS.Workbook();
  wb.creator = '升學導航平台';
  wb.created = new Date();
  wb.modified = new Date();
  
  // 1. Summary Sheet
  const summary = [
    ["115年 會考落點分析結果報告"],
    ["", ""],
    ["【基本資料】"],
    ["產生日期", new Date().toLocaleString('zh-TW')],
    ["分析區域", regionName],
    ["選取偏好-公立私立", data.scores.schoolOwnership === 'all' ? '公立與私立整體評選' : data.scores.schoolOwnership === 'public' ? '僅評選公立學校' : '僅評選私立學校'],
    ["選取偏好-學校類型", data.scores.schoolType === 'all' ? '普通與職業類科' : data.scores.schoolType],
    ...(data.scores.schoolType === '職業類科' && data.vocationalGroups ? [["選取偏好-職業群別", data.vocationalGroups.includes('all') ? '全群別不拘' : data.vocationalGroups.join(', ')]] : []),
    ["使用者身份", data.identity === 'student' ? '學生' : data.identity === 'teacher' ? '老師' : '家長'],
    ["", ""],
    ["【會考成績】"],
    ["國文", data.scores.chinese],
    ["英文", data.scores.english],
    ["數學", data.scores.math],
    ["自然", data.scores.science],
    ["社會", data.scores.social],
    ["作文級分", data.scores.composition],
    ["", ""],
    ["【運算結果】"],
    ["總積分", data.results.totalPoints],
    ["總積點 (若適用)", data.results.totalCredits || "無"],
    ["", ""],
    ["【免責聲明】"],
    ["本系統結果僅供參考，不代表最終錄取結果。請務必以發布之簡章為準。"],
    ["版權宣告", `TW全國會考落點分析 © ${new Date().getFullYear()}`],
    ["分析來源網址", window.location.href]
  ];
  const summaryWs = wb.addWorksheet("分析摘要與成績");
  summaryWs.addRows(summary);
  summaryWs.mergeCells('A1:B1');
  summaryWs.views = [{ showGridLines: false }];
  summaryWs.pageSetup = { orientation: 'portrait', fitToPage: true, fitToWidth: 1, fitToHeight: 0 };
  summaryWs.pageSetup.margins = { left: 0.3, right: 0.3, top: 0.5, bottom: 0.5, header: 0.2, footer: 0.2 };
  summaryWs.headerFooter.oddFooter = '第 &P 頁，共 &N 頁';
  summaryWs.getColumn(1).width = 28;
  summaryWs.getColumn(2).width = 48;
  summaryWs.getRow(1).height = 30;
  summaryWs.getCell('A1').font = { bold: true, size: 16, color: { argb: 'FFFFFFFF' } };
  summaryWs.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A8A' } };
  summaryWs.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
  summaryWs.eachRow((row, rowNumber) => {
    if (rowNumber === 1 || !row.getCell(1).value) return;
    const label = String(row.getCell(1).value);
    const value = row.getCell(2);
    if (!value.value && label.length < 30) {
      summaryWs.mergeCells(`A${rowNumber}:B${rowNumber}`);
      row.getCell(1).font = { bold: true, color: { argb: 'FF1E3A8A' } };
      row.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E7FF' } };
      row.getCell(1).alignment = { vertical: 'middle', horizontal: 'left' };
      row.height = 22;
      return;
    }
    row.getCell(1).font = { bold: true, color: { argb: 'FF334155' } };
    value.alignment = { vertical: 'middle', wrapText: true };
    row.getCell(1).border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
    value.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
  });

  // 2. Schools Sheet
  if (data.results.eligibleSchools?.length) {
    const schoolsData = [
      ["推薦排序", "學校名稱", "群別/科系", "學校類型", "公立/私立", "落點區間", "預估錄取門檻"],
      ...data.results.eligibleSchools.map((s: any, index: number) => [
        index + 1,
        s.name, 
        s.group || "--",
        s.type, 
        formatSchoolOwnership(s.ownership),
        s.zone === 'reach' ? '夢幻區' : s.zone === 'target' ? '實際區' : s.zone === 'safe' ? '保守區' : "--",
        s.minScore || s.points || s.score || "--"
      ])
    ];
    const schoolsWs = wb.addWorksheet("推薦學校清單");
    schoolsWs.addRows(schoolsData);
    schoolsWs.views = [{ state: 'frozen', ySplit: 1, showGridLines: false }];
    schoolsWs.pageSetup = { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 };
    schoolsWs.pageSetup.margins = { left: 0.25, right: 0.25, top: 0.45, bottom: 0.45, header: 0.2, footer: 0.2 };
    schoolsWs.headerFooter.oddFooter = '第 &P 頁，共 &N 頁';
    schoolsWs.autoFilter = { from: 'A1', to: `G${schoolsWs.rowCount}` };
    [10, 28, 22, 18, 12, 14, 18].forEach((width, index) => {
      schoolsWs.getColumn(index + 1).width = width;
    });
    const schoolsHeader = schoolsWs.getRow(1);
    schoolsHeader.height = 26;
    schoolsHeader.eachCell((cell) => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E3A8A' } };
      cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
    });
    for (let rowNumber = 2; rowNumber <= schoolsWs.rowCount; rowNumber += 1) {
      const row = schoolsWs.getRow(rowNumber);
      row.height = 22;
      row.eachCell((cell) => {
        cell.alignment = { vertical: 'middle', wrapText: true };
        cell.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
      });
      row.getCell(1).alignment = { horizontal: 'center', vertical: 'middle' };
      row.getCell(6).alignment = { horizontal: 'center', vertical: 'middle' };
      row.getCell(7).alignment = { horizontal: 'right', vertical: 'middle' };
      const zoneCell = row.getCell(6);
      const zone = data.results.eligibleSchools[rowNumber - 2]?.zone;
      const zoneColors: Record<string, string> = { reach: 'FFFEE2E2', target: 'FFFEF3C7', safe: 'FFDCFCE7' };
      if (zoneColors[zone]) {
        zoneCell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: zoneColors[zone] } };
        zoneCell.font = { bold: true, color: { argb: 'FF334155' } };
      }
    }
    
  } else {
    const emptyWs = wb.addWorksheet("推薦學校清單");
    emptyWs.addRow(["無符合條件之推薦學校"]);
  }

  const content = await wb.xlsx.writeBuffer();
  saveAs(
    new Blob([content], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }),
    `115年_會考落點分析_${regionName}.xlsx`,
  );
};

type ComparisonExportOptions = {
  schools: any[];
  visibleFields: string[];
};

const comparisonFieldLabels: Record<string, string> = {
  region: '就學區',
  type: '學校類型',
  ownership: '公立／私立',
  group: '特色及群別',
  historicalScores: '歷年成績',
  admissionQuota: '招生名額（一般生）',
  map: '學校地圖',
};

const formatComparisonHistoricalScores = (school: any) => {
  const scores = Array.isArray(school.historicalScores) ? school.historicalScores : [];
  const values = scores
    .filter((item) => item && item.points !== null && item.points !== undefined)
    .sort((left, right) => Number(right.year) - Number(left.year))
    .slice(0, 4)
    .map((item) => `${item.year || '歷年'}：${item.points} 分／${item.credits ?? '無'} 點`);
  return values.length ? values.join('\n') : '資料建置中';
};

const getComparisonFieldValue = (school: any, field: string): string | number => {
  if (field === 'region') return school.region || '未提供';
  if (field === 'type') return school.type || '未提供';
  if (field === 'ownership') return formatSchoolOwnership(school.ownership);
  if (field === 'group') return school.group || '—';
  if (field === 'historicalScores') return formatComparisonHistoricalScores(school);
  if (field === 'admissionQuota') return school.admissionQuota === null || school.admissionQuota === undefined ? '尚未公告' : Number(school.admissionQuota);
  if (field === 'map') return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(school.name || '')}`;
  return '—';
};

const getComparisonColumns = (visibleFields: string[]) => [
  { id: 'name', label: '學校（科系）' },
  ...visibleFields.filter((field) => field !== 'map' && comparisonFieldLabels[field]).map((field) => ({ id: field, label: comparisonFieldLabels[field] })),
];

export const exportComparisonExcel = async ({ schools, visibleFields }: ComparisonExportOptions) => {
  const columns = getComparisonColumns(visibleFields);
  const workbook = new ExcelJS.Workbook();
  workbook.creator = 'TW 全國會考落點分析';
  workbook.created = new Date();
  const worksheet = workbook.addWorksheet('比較表');
  const lastColumn = String.fromCharCode(64 + columns.length);

  worksheet.mergeCells(`A1:${lastColumn}1`);
  worksheet.getCell('A1').value = '會考落點分析｜學校比較表';
  worksheet.getCell('A1').font = { bold: true, size: 16, color: { argb: 'FFFFFFFF' } };
  worksheet.getCell('A1').fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4F46E5' } };
  worksheet.getCell('A1').alignment = { horizontal: 'center', vertical: 'middle' };
  worksheet.getRow(1).height = 30;
  worksheet.mergeCells(`A2:${lastColumn}2`);
  worksheet.getCell('A2').value = `匯出時間：${new Date().toLocaleString('zh-TW')}｜共 ${schools.length} 所學校`;
  worksheet.getCell('A2').font = { bold: true, color: { argb: 'FF475569' } };
  worksheet.getCell('A2').alignment = { horizontal: 'left', vertical: 'middle' };
  worksheet.getRow(2).height = 22;
  worksheet.addRow(columns.map((column) => column.label));
  const headerRow = worksheet.getRow(3);
  headerRow.height = 26;
  headerRow.eachCell((cell) => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF1E293B' } };
    cell.alignment = { horizontal: 'center', vertical: 'middle', wrapText: true };
  });

  schools.forEach((school) => {
    const row = worksheet.addRow(columns.map((column) => column.id === 'name' ? school.name || '未命名學校' : getComparisonFieldValue(school, column.id)));
    row.height = visibleFields.includes('historicalScores') ? 56 : 24;
    row.eachCell((cell) => {
      cell.alignment = { vertical: 'middle', wrapText: true };
      cell.border = { bottom: { style: 'thin', color: { argb: 'FFE2E8F0' } } };
    });
  });
  worksheet.views = [{ state: 'frozen', ySplit: 3, showGridLines: false }];
  const tableEndRow = worksheet.rowCount;
  worksheet.autoFilter = { from: 'A3', to: `${lastColumn}${tableEndRow}` };
  worksheet.pageSetup = { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 };
  worksheet.pageSetup.margins = { left: 0.25, right: 0.25, top: 0.45, bottom: 0.45, header: 0.2, footer: 0.2 };
  worksheet.headerFooter.oddFooter = '第 &P 頁，共 &N 頁';
  columns.forEach((column, index) => {
    worksheet.getColumn(index + 1).width = column.id === 'name' ? 28 : column.id === 'historicalScores' ? 36 : column.id === 'map' ? 54 : 18;
  });
  worksheet.addRow([]);
  const websiteRow = worksheet.addRow([`網站網址：${window.location.href}`]);
  worksheet.mergeCells(`A${websiteRow.number}:${lastColumn}${websiteRow.number}`);
  websiteRow.getCell(1).font = { bold: true, color: { argb: 'FF475569' } };
  websiteRow.getCell(1).alignment = { vertical: 'middle', wrapText: true };
  const disclaimerRow = worksheet.addRow(['免責聲明：本系統分析結果僅供參考，不代表實際錄取結果；請以各校最新官方招生簡章與公告為準。']);
  worksheet.mergeCells(`A${disclaimerRow.number}:${lastColumn}${disclaimerRow.number}`);
  disclaimerRow.getCell(1).font = { bold: true, color: { argb: 'FF92400E' } };
  disclaimerRow.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFFFF7ED' } };
  disclaimerRow.getCell(1).alignment = { vertical: 'middle', wrapText: true };
  disclaimerRow.height = 32;

  const content = await workbook.xlsx.writeBuffer();
  saveAs(new Blob([content], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }), `會考落點分析_學校比較_${new Date().toISOString().slice(0, 10)}.xlsx`);
};

export const printComparison = ({ schools, visibleFields }: ComparisonExportOptions, existingWindow?: Window) => {
  const printWindow = existingWindow || window.open('', '_blank');
  if (!printWindow) {
    alert('無法開啟列印視窗，請檢查是否被瀏覽器阻擋。');
    return;
  }
  const columns = getComparisonColumns(visibleFields);
  const headerHtml = columns.map((column) => `<th>${escapeHtml(column.label)}</th>`).join('');
  const rowsHtml = schools.map((school) => `<tr>${columns.map((column) => {
    const value = column.id === 'name' ? school.name || '未命名學校' : getComparisonFieldValue(school, column.id);
    return `<td>${escapeHtml(value).replace(/\n/g, '<br>')}</td>`;
  }).join('')}</tr>`).join('');

  printWindow.document.write(`<!doctype html><html lang="zh-Hant"><head><meta charset="utf-8"><title>會考落點分析｜學校比較表</title><style>body{font-family:"Noto Sans TC","Microsoft JhengHei",Arial,sans-serif;color:#0f172a;margin:28px}h1{margin:0;font-size:24px}p{color:#475569;font-size:12px}table{width:100%;border-collapse:collapse;margin-top:20px;font-size:12px}th{background:#1e293b;color:#fff;text-align:left;padding:10px;border:1px solid #0f172a}td{vertical-align:top;padding:9px;border:1px solid #cbd5e1;line-height:1.55}tr:nth-child(even){background:#f8fafc}.print-footer{margin-top:18px;border-top:2px solid #cbd5e1;padding-top:10px;font-size:11px;line-height:1.65;color:#475569}.print-footer strong{color:#92400e}@page{size:landscape;margin:12mm}@media print{body{margin:0}thead{display:table-header-group}tr{break-inside:avoid}}</style></head><body><h1>會考落點分析｜學校比較表</h1><p>列印時間：${escapeHtml(new Date().toLocaleString('zh-TW'))}　・　共 ${schools.length} 所學校</p><table><thead><tr>${headerHtml}</tr></thead><tbody>${rowsHtml}</tbody></table><footer class="print-footer"><div>網站網址：${escapeHtml(window.location.href)}</div><div><strong>免責聲明：</strong>本系統分析結果僅供參考，不代表實際錄取結果；請以各校最新官方招生簡章與公告為準。</div></footer></body></html>`);
  printWindow.document.close();
  printWindow.focus();
  window.setTimeout(() => printWindow.print(), 250);
};

export const printResults = (data: any, regionName: string, existingWindow?: Window) => {
  // `data` may contain values from shared reports and database records. Escape
  // every string before it is interpolated into the popup HTML below.
  data = escapePrintData(data) as typeof data;
  regionName = escapeHtml(regionName);

  const printWindow = existingWindow || window.open('', '_blank');
  if (!printWindow) {
    alert('無法開啟列印視窗，請檢查是否被瀏覽器阻擋。');
    return;
  }

  const identityStr = data.identity === 'student' ? '學生' : data.identity === 'teacher' ? '老師' : '家長';
  const ownershipStr = data.scores.schoolOwnership === 'all' ? '公私立不拘' : data.scores.schoolOwnership === 'public' ? '公立' : '私立';
  const typeStr = data.scores.schoolType === 'all' ? '普通與職業類科' : data.scores.schoolType;
  const groupStr = data.scores.schoolType === '職業類科' && data.vocationalGroups ? `<div class="info-item"><div class="info-label">職業群別</div><div class="info-value">${data.vocationalGroups.includes('all') ? '全群別不拘' : data.vocationalGroups.join(', ')}</div></div>` : '';

  const rawCurrentUrl = window.location.href;
  // Keep the raw URL for QR encoding, but never interpolate it into popup HTML.
  const currentUrl = escapeHtml(rawCurrentUrl);
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(rawCurrentUrl)}`;

  let creditsHtml = '';
  if (data.results.totalCredits) {
    creditsHtml = `<div class="result-point">總積點：<strong>${data.results.totalCredits}</strong></div>`;
  }

  let analysisReportHtml = '';
  if (data.results.analysisReport) {
    const report = data.results.analysisReport;
    analysisReportHtml = `
      <div class="report-card">
        <div class="report-header">
          <div class="report-badge">AI 智能報告</div>
          <h3>${report.analysisSummary}</h3>
        </div>
        <div class="report-metrics">
          <div class="metric-item">
            <span class="metric-label">夢幻區間</span>
            <span class="metric-val text-reach">${report.zoneCounts?.reach || 0}</span>
          </div>
          <div class="metric-item">
            <span class="metric-label">實際區間</span>
            <span class="metric-val text-target">${report.zoneCounts?.target || 0}</span>
          </div>
          <div class="metric-item">
            <span class="metric-label">保守區間</span>
            <span class="metric-val text-safe">${report.zoneCounts?.safe || 0}</span>
          </div>
        </div>
        <div class="report-suggestion">
          <strong>策略建議：</strong>${report.suggestion}
        </div>
      </div>
    `;
  }

  let schoolsHtml = '<p style="text-align: center; padding: 20px; color: #64748b;">無符合條件之推薦學校</p>';
  if (data.results.eligibleSchools && data.results.eligibleSchools.length > 0) {
    let rowsHtml = '';
    data.results.eligibleSchools.forEach((s: any, i: number) => {
      const thresholdScore = s.minScore || s.points || s.score || '--';
      const zoneText = s.zone === 'reach' ? '夢幻區' : s.zone === 'target' ? '實際區' : s.zone === 'safe' ? '保守區' : '--';

      rowsHtml += `
      <tr>
        <td class="preference-cell"></td>
        <td style="font-weight: 600; color: #64748b;">#${i + 1}</td>
        <td style="font-weight: 700; color: #0f172a;">${s.name}</td>
        <td>${s.group || s.type || '-'}</td>
        <td>${formatSchoolOwnership(s.ownership)}</td>
        <td><span class="badge eval-${s.zone || 'normal'}">${zoneText}</span></td>
        <td style="font-weight: 600;">${thresholdScore}</td>
      </tr>
      `;
    });

    schoolsHtml = `
      <table class="schools-table">
        <colgroup>
          <col style="width: 8%" />
          <col style="width: 7%" />
          <col style="width: 33%" />
          <col style="width: 10%" />
          <col style="width: 9%" />
          <col style="width: 15%" />
          <col style="width: 18%" />
        </colgroup>
        <thead>
          <tr>
            <th class="preference-heading">&#24535;&#39000;&#25490;&#24207;</th>
            <th width="10%">排序</th>
            <th width="25%">學校名稱</th>
            <th width="25%">群別/科系/類型</th>
            <th width="10%">公私立</th>
            <th width="15%">落點區間</th>
            <th width="15%">預估錄取門檻</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>
    `;
  }

  const html = `
    <!DOCTYPE html>
    <html lang="zh-TW">
    <head>
      <meta charset="UTF-8">
      <title>115年會考落點分析報告 - ${regionName}</title>
      <style>
        @page { size: A4 portrait; margin: 1cm; }
        * { box-sizing: border-box; }
        body {
          font-family: 'Helvetica Neue', 'PingFang TC', 'Microsoft JhengHei', sans-serif;
          color: #1e293b;
          line-height: 1.6;
          margin: 0;
          padding: 0;
          background: #f1f5f9;
          -webkit-print-color-adjust: exact;
          print-color-adjust: exact;
        }
        .print-wrapper {
          position: relative;
          max-width: 210mm;
          margin: 20px auto;
          background: #fff;
          padding: 40px;
          border-radius: 12px;
          box-shadow: 0 4px 20px rgba(0,0,0,0.08);
          border-top: 12px solid #2563eb;
          overflow: hidden;
        }
        @media print {
          body { background: #fff; }
          .print-wrapper { box-shadow: none; padding: 0; margin: 0; width: 100%; max-width: none; border-radius: 0; border-top: 8px solid #2563eb; }
          .btn-print { display: none !important; }
        }
        /* Optional watermark for a professional look */
        .watermark {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translate(-50%, -50%) rotate(-30deg);
          font-size: 120px;
          color: rgba(226, 232, 240, 0.3);
          font-weight: 900;
          white-space: nowrap;
          pointer-events: none;
          z-index: 0;
          user-select: none;
        }
        .content-relative {
          position: relative;
          z-index: 10;
        }
        .header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          border-bottom: 3px solid #0f172a;
          padding-bottom: 20px;
          margin-bottom: 30px;
        }
        .header-left h1 {
          margin: 0 0 8px 0;
          font-size: 32px;
          color: #0f172a;
          letter-spacing: 1.5px;
          font-weight: 800;
        }
        .header-left p {
          margin: 0;
          color: #475569;
          font-size: 14px;
        }
        .header-right {
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: flex-end;
        }
        .qr-box {
          background: #fff;
          padding: 6px;
          border: 2px solid #e2e8f0;
          border-radius: 8px;
          display: inline-block;
        }
        .qr-box img {
          width: 76px;
          height: 76px;
          display: block;
        }
        .site-link {
          font-size: 10px;
          color: #64748b;
          margin-top: 6px;
          max-width: 150px;
          word-break: break-all;
          line-height: 1.3;
        }
        .section { margin-bottom: 32px; }
        .section-title {
          font-size: 18px;
          font-weight: 700;
          color: #1e3a8a;
          background-color: #eff6ff;
          padding: 8px 16px;
          border-radius: 6px;
          border-left: 5px solid #2563eb;
          margin-bottom: 16px;
          display: inline-block;
          min-width: 200px;
        }
        .info-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 16px;
          background: #f8fafc;
          padding: 24px;
          border-radius: 12px;
          border: 1px solid #e2e8f0;
        }
        .info-item { display: flex; align-items: center; }
        .info-label { font-weight: 600; color: #64748b; width: 90px; flex-shrink: 0; font-size: 14px; }
        .info-value { font-weight: 800; color: #0f172a; font-size: 16px; }
        
        .scores-wrapper {
          display: flex;
          gap: 20px;
          align-items: stretch;
        }
        .scores-grid {
          flex: 2;
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 12px;
          background: #fff;
          padding: 20px;
          border-radius: 12px;
          border: 1px solid #e2e8f0;
        }
        .score-item {
          text-align: center;
          padding: 12px 8px;
          background: #f8fafc;
          border-radius: 8px;
          border: 1px solid #f1f5f9;
        }
        .score-label { font-size: 13px; color: #64748b; margin-bottom: 4px; font-weight: 600; }
        .score-val { font-size: 24px; font-weight: 800; color: #2563eb; }
        .score-val.comp { color: #7c3aed; }
        
        .result-summary {
          flex: 1;
          background: #eff6ff;
          border: 1px solid #bfdbfe;
          padding: 24px;
          border-radius: 12px;
          display: flex;
          flex-direction: column;
          justify-content: center;
        }
        .result-summary-title { font-size: 15px; font-weight: 800; color: #1e40af; margin-bottom: 12px; }
        .result-point { font-size: 15px; margin-bottom: 8px; color: #1e3a8a; font-weight: 600; }
        .result-point strong { font-size: 32px; color: #1d4ed8; font-weight: 800; margin-left: 8px; }
        
        /* Report Card Styles */
        .report-card {
          background: #f8fafc;
          border-radius: 16px;
          border: 2px solid #0f172a;
          padding: 24px;
          margin-bottom: 30px;
          box-shadow: 4px 4px 0px 0px #0f172a;
        }
        .report-header {
          display: flex;
          align-items: center;
          gap: 12px;
          margin-bottom: 16px;
        }
        .report-badge {
          background: #0f172a;
          color: white;
          padding: 4px 10px;
          border-radius: 8px;
          font-size: 11px;
          font-weight: 900;
          text-transform: uppercase;
        }
        .report-header h3 {
          margin: 0;
          font-size: 18px;
          font-weight: 800;
          color: #0f172a;
        }
        .report-metrics {
          display: flex;
          gap: 12px;
          margin-bottom: 20px;
        }
        .metric-item {
          flex: 1;
          padding: 12px;
          background: white;
          border-radius: 12px;
          border: 2px solid #e2e8f0;
          display: flex;
          flex-direction: column;
          align-items: center;
        }
        .metric-label { font-size: 11px; font-weight: 700; color: #64748b; margin-bottom: 4px; }
        .metric-val { font-size: 20px; font-weight: 900; }
        .text-reach { color: #f43f5e; }
        .text-target { color: #0ea5e9; }
        .text-safe { color: #10b981; }
        .report-suggestion {
          background: #f1f5f9;
          padding: 16px;
          border-radius: 12px;
          font-size: 14px;
          color: #334155;
          line-height: 1.6;
        }

        :root { --print-table-grid: #94a3b8; }
        table {
          width: 100%;
          border-collapse: collapse;
          border: 1px solid var(--print-table-grid);
        }
        th, td { padding: 14px 16px; text-align: left; border: 1px solid var(--print-table-grid); font-size: 14px; }
        th { 
          background-color: #f8fafc; 
          font-weight: 800; 
          color: #334155; 
          font-size: 14px; 
        }
        tbody tr { background-color: #fff; }
        tbody tr:hover { background-color: #f1f5f9; }
        
        .badge { display: inline-block; padding: 4px 10px; border-radius: 999px; font-size: 12px; font-weight: 700; }
        .eval-safe { background: #dcfce7; color: #166534; }
        .eval-target { background: #dbeafe; color: #1e40af; }
        .eval-normal { background: #f1f5f9; color: #475569; }
        .eval-reach { background: #fee2e2; color: #991b1b; }
        .eval-low { background: #fee2e2; color: #991b1b; }
        
        .btn-print {
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 8px;
          width: 180px;
          margin: 0 auto 30px auto;
          padding: 12px 24px;
          background-color: #0f172a;
          color: white;
          text-align: center;
          border-radius: 8px;
          font-size: 15px;
          font-weight: bold;
          cursor: pointer;
          border: none;
          box-shadow: 0 4px 6px rgba(15, 23, 42, 0.2);
          transition: all 0.2s;
        }
        .btn-print:hover { background-color: #334155; transform: translateY(-1px); }
        .btn-print svg { width: 18px; height: 18px; }
        
        .footer {
          margin-top: 50px;
          padding-top: 24px;
          border-top: 2px solid #e2e8f0;
          font-size: 12px;
          color: #64748b;
          text-align: center;
          line-height: 1.8;
        }
        .footer p { margin: 4px 0; }
        .footer strong { color: #0f172a; }

        /* Results report redesign: a calmer editorial layout that remains
           legible on both screen previews and A4 printouts. */
        body {
          background: #eef4ff;
          color: #172033;
          font-family: "Noto Sans TC", "PingFang TC", "Microsoft JhengHei", sans-serif;
        }
        .print-wrapper {
          max-width: 190mm;
          margin: 18px auto;
          padding: 12mm 12mm 10mm;
          border: 0;
          border-top: 9px solid #2563eb;
          border-radius: 18px;
          box-shadow: 0 18px 55px rgba(30, 64, 175, .12);
        }
        .watermark { display: none; }
        /* First-page report masthead */
        .header {
          position: relative;
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 18px;
          align-items: stretch;
          overflow: hidden;
          margin: -12mm -12mm 24px;
          padding: 13mm 12mm 10mm;
          border: 0;
          background: linear-gradient(135deg, #f8fbff 0%, #eef6ff 58%, #f5f3ff 100%);
          color: #0f172a;
        }
        .header::before {
          position: absolute;
          top: -54mm;
          right: -21mm;
          width: 108mm;
          height: 108mm;
          border: 1px solid rgba(96, 165, 250, .24);
          border-radius: 50%;
          box-shadow: 0 0 0 13mm rgba(96, 165, 250, .10), 0 0 0 28mm rgba(167, 139, 250, .08);
          content: "";
        }
        .header::after {
          position: absolute;
          bottom: 0;
          left: 0;
          width: 100%;
          height: 4px;
          border-radius: 99px;
          background: linear-gradient(90deg, #38bdf8, #a78bfa);
          content: "";
        }
        .header-left, .header-right { position: relative; z-index: 1; }
        .report-region {
          position: absolute;
          z-index: 1;
          right: 12mm;
          bottom: 10mm;
          color: #64748b;
          font-size: 9px;
          letter-spacing: .06em;
        }
        .report-region strong { margin-left: 5px; color: #1e3a8a; font-size: 11px; font-weight: 800; }
        /* The legacy label markup is deliberately replaced visually here so
           the masthead remains clean even for reports generated from older
           saved payloads. */
        .header-left h1, .header-left p { display: none; }
        .header-left::before {
          display: block;
          max-width: 430px;
          color: #0f172a;
          font-size: 29px;
          font-weight: 900;
          letter-spacing: .035em;
          line-height: 1.22;
          content: "會考落點分析結果報告";
        }
        .header-left::after {
          display: block;
          margin-top: 11px;
          color: #475569;
          font-size: 10px;
          font-weight: 600;
          letter-spacing: .04em;
          content: "PERSONALISED ADMISSION PLANNING REPORT";
        }
        .report-kicker {
          display: flex;
          align-items: center;
          gap: 7px;
          margin: 0 0 8px;
          color: #1d4ed8;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: .16em;
        }
        .report-kicker::before {
          width: 8px;
          height: 8px;
          border-radius: 50%;
          background: #38bdf8;
          box-shadow: 0 0 0 4px rgba(56, 189, 248, .16);
          content: "";
        }
        .header-left h1 {
          max-width: 430px;
          margin: 0;
          color: #0f172a;
          font-size: 29px;
          font-weight: 900;
          letter-spacing: .035em;
          line-height: 1.22;
        }
        .header-left p {
          display: flex;
          flex-wrap: wrap;
          gap: 5px 13px;
          margin: 10px 0 0;
          padding: 0;
          border: 0;
          border-radius: 0;
          background: transparent;
          color: #475569;
          font-size: 10px;
          font-weight: 600;
        }
        .header-left p strong { color: #1e3a8a; font-weight: 800; }
        .header-right {
          display: flex;
          flex-direction: row;
          align-items: center;
          gap: 10px;
          min-width: 168px;
          margin-bottom: 20px;
          padding: 8px 10px;
          border: 1px solid #bfdbfe;
          border-radius: 12px;
          background: rgba(255, 255, 255, .84);
          box-shadow: 0 7px 18px rgba(30, 64, 175, .08);
          text-align: left;
        }
        .qr-box { flex: 0 0 auto; padding: 4px; border: 1px solid #e2e8f0; border-radius: 7px; background: #fff; }
        .qr-box img { width: 54px; height: 54px; }
        .site-link { max-width: 84px; margin: 0; color: #475569; font-size: 0; line-height: 1.45; word-break: normal; }
        .site-link::before {
          display: block;
          font-size: 8px;
          content: "\\6383 \\63cf QR Code\\A \\958b\\555f\\5b8c\\6574\\5831\\544a";
          white-space: pre;
        }
        .site-link::before { display: block; font-size: 8px; content: "掃描 QR Code\A 開啟完整報告"; white-space: pre; }
        .site-link::before {
          content: "\\6383 \\63cf QR Code\\A \\958b\\555f\\5b8c\\6574\\5831\\544a";
        }
        .section { margin-bottom: 20px; break-inside: avoid; }
        .section-title {
          display: flex;
          align-items: center;
          gap: 8px;
          min-width: 0;
          margin: 0 0 10px;
          padding: 0;
          border: 0;
          border-radius: 0;
          background: transparent;
          color: #0f172a;
          font-size: 16px;
          font-weight: 900;
        }
        .section-title::before {
          width: 7px;
          height: 22px;
          border-radius: 99px;
          background: linear-gradient(180deg, #2563eb, #7c3aed);
          content: "";
        }
        .info-grid {
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 1px;
          padding: 1px;
          overflow: hidden;
          border: 1px solid #dbeafe;
          border-radius: 12px;
          background: #dbeafe;
        }
        .info-item { min-height: 52px; padding: 10px 12px; background: #fff; }
        .info-label { width: 76px; color: #64748b; font-size: 11px; }
        .info-value { color: #1e293b; font-size: 14px; }
        .scores-wrapper { gap: 12px; }
        .scores-grid {
          grid-template-columns: repeat(3, 1fr);
          gap: 7px;
          padding: 0;
          border: 0;
          background: transparent;
        }
        .score-item { padding: 10px 6px; border: 1px solid #dbeafe; border-radius: 10px; background: #f8fbff; }
        .score-label { margin-bottom: 2px; color: #64748b; font-size: 11px; }
        .score-val { color: #1d4ed8; font-size: 20px; line-height: 1.15; }
        .result-summary {
          min-width: 148px;
          padding: 15px;
          border: 0;
          border-radius: 12px;
          background: linear-gradient(135deg, #1d4ed8, #4338ca);
          color: #fff;
        }
        .result-summary-title, .result-point, .result-summary div { color: #dbeafe !important; }
        .result-summary-title { margin-bottom: 8px; font-size: 11px; }
        .result-point { margin-bottom: 3px; font-size: 12px; }
        .result-point strong { display: block; margin: 0; color: #fff; font-size: 31px; line-height: 1.1; }
        .report-card {
          padding: 17px;
          border: 1px solid #c7d2fe;
          border-radius: 14px;
          background: linear-gradient(135deg, #f8faff, #f5f3ff);
          box-shadow: none;
        }
        .report-header { gap: 9px; margin-bottom: 12px; }
        .report-badge { border-radius: 2px; background: #312e81; font-size: 9px; }
        .report-header h3 { font-size: 15px; line-height: 1.5; }
        .report-metrics { gap: 8px; margin-bottom: 12px; }
        .metric-item { padding: 9px 6px; border: 1px solid #e0e7ff; border-radius: 9px; }
        .metric-label { font-size: 10px; }
        .metric-val { font-size: 18px; }
        .report-suggestion { padding: 12px; border-left: 3px solid #818cf8; border-radius: 7px; background: #fff; font-size: 12px; }
        table { border: 1px solid var(--print-table-grid); border-radius: 0; }
        th, td { padding: 9px 10px; font-size: 11px; line-height: 1.4; }
        th { background: #0f172a; color: #fff; font-size: 10px; letter-spacing: .02em; }
        .schools-table {
          width: 100%;
          table-layout: fixed;
        }
        .schools-table th,
        .schools-table td {
          padding: 7px 6px;
          overflow-wrap: anywhere;
        }
        .schools-table th { text-align: center; }
        .schools-table td:nth-child(1),
        .schools-table td:nth-child(2),
        .schools-table td:nth-child(5),
        .schools-table td:nth-child(6),
        .schools-table td:nth-child(7) { text-align: center; }
        .schools-table .preference-heading {
          width: 12%;
          background: #1e3a8a;
          text-align: center;
          white-space: nowrap;
          border-right: 1px solid var(--print-table-grid);
        }
        .schools-table .preference-cell {
          padding: 5px 7px;
          text-align: center;
          vertical-align: middle;
          border-right: 1px solid var(--print-table-grid);
          border-bottom: 1px solid var(--print-table-grid);
        }
        tbody tr { background: #fff; }
        tbody tr { break-inside: avoid; page-break-inside: avoid; }
        thead { display: table-header-group; }
        .schools-table td:nth-child(6) { text-align: center; }
        .schools-table .badge {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-width: 48px;
          padding: 4px 8px;
          border: 1px solid transparent;
          border-radius: 999px;
          font-size: 10px;
          font-weight: 800;
          letter-spacing: .04em;
          line-height: 1.1;
          white-space: nowrap;
        }
        .schools-table .eval-reach { border-color: #fca5a5; background: #fef2f2; color: #b91c1c; }
        .schools-table .eval-target { border-color: #93c5fd; background: #eff6ff; color: #1d4ed8; }
        .schools-table .eval-safe { border-color: #86efac; background: #f0fdf4; color: #15803d; }
        .schools-table .eval-normal { border-color: #cbd5e1; background: #f8fafc; color: #475569; }
        .footer { margin-top: 26px; padding-top: 14px; border-top: 1px solid #cbd5e1; font-size: 9px; }
        .footer {
          margin-top: 28px;
          padding: 14px 16px;
          border: 1px solid #cbd5e1;
          border-radius: 12px;
          background: #f8fafc;
          text-align: left;
        }
        .footer > p { display: none; }
        .report-disclaimer { display: grid; gap: 8px; }
        .report-disclaimer-label {
          display: inline-flex;
          align-items: center;
          width: fit-content;
          padding: 4px 8px;
          border-radius: 5px;
          background: #fff7ed;
          color: #9a3412;
          font-size: 10px;
          font-weight: 900;
          letter-spacing: .06em;
        }
        .report-disclaimer-copy {
          margin: 0;
          color: #475569;
          font-size: 10px;
          font-weight: 600;
          line-height: 1.75;
        }
        .report-disclaimer-meta {
          display: flex;
          flex-wrap: wrap;
          gap: 4px 10px;
          padding-top: 9px;
          border-top: 1px solid #e2e8f0;
          color: #64748b;
          font-size: 9px;
          font-weight: 700;
        }
        .report-disclaimer-meta strong { color: #1e3a8a; }
        .report-disclaimer-meta a { color: #2563eb; text-decoration: none; }
        @media print {
          @page { margin: 8mm; }
          body { background: #fff; }
          .print-wrapper { max-width: none; margin: 0; padding: 0; border-top-width: 6px; box-shadow: none; }
          .header { margin: 0 0 7mm; padding: 10mm 9mm 8mm; }
          .report-region { right: 9mm; bottom: 8mm; }
          .section { break-inside: avoid; page-break-inside: avoid; }
          .btn-print { display: none !important; }
        }
      </style>
    </head>
    <body>
      <button class="btn-print" type="button">
        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
        列印分析報告
      </button>
      
      <div class="print-wrapper">
        <div class="watermark">落點分析</div>
        <div class="content-relative">
          <div class="header">
          <div class="report-region">分析區域 <strong>${regionName}</strong></div>
          <div class="header-left">
            <h1>115年會考落點分析報告</h1>
            <p>分析區域：<strong>${regionName}</strong> &nbsp;|&nbsp; 報告產生時間：${new Date().toLocaleString('zh-TW')}</p>
          </div>
          <div class="header-right">
            <div class="qr-box">
              <img src="${qrCodeUrl}" alt="QR Code" />
            </div>
            <div class="site-link">掃描查看原網站<br/>${currentUrl}</div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">考生基本設定</div>
          <div class="info-grid">
            <div class="info-item"><div class="info-label">使用者身份</div><div class="info-value">${identityStr}</div></div>
            <div class="info-item"><div class="info-label">學校屬性</div><div class="info-value">${ownershipStr}</div></div>
            <div class="info-item"><div class="info-label">學校類型</div><div class="info-value">${typeStr}</div></div>
            ${groupStr}
            <div class="info-item"><div class="info-label">系統辨識碼</div><div class="info-value" style="font-family: monospace; color: #64748b;">${data.scores.invitationCode || '---'}</div></div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">會考成績與積分試算</div>
          <div class="scores-wrapper">
            <div class="scores-grid">
              <div class="score-item"><div class="score-label">國文</div><div class="score-val">${data.scores.chinese}</div></div>
              <div class="score-item"><div class="score-label">英文</div><div class="score-val">${data.scores.english}</div></div>
              <div class="score-item"><div class="score-label">數學</div><div class="score-val">${data.scores.math}</div></div>
              <div class="score-item"><div class="score-label">自然</div><div class="score-val">${data.scores.science}</div></div>
              <div class="score-item"><div class="score-label">社會</div><div class="score-val">${data.scores.social}</div></div>
              <div class="score-item"><div class="score-label">寫作測驗</div><div class="score-val comp">${data.scores.composition} 級分</div></div>
            </div>
            <div class="result-summary">
              <div class="result-summary-title">落點分析引擎試算結果</div>
              <div class="result-point">總積分：<strong>${data.results.totalPoints}</strong></div>
              ${creditsHtml}
              <div style="margin-top: 10px; font-size: 13px; color: #1e3a8a;">
                符合條件推薦學校：<strong>${data.results.eligibleSchools?.length || 0}</strong> 所
              </div>
            </div>
          </div>
        </div>

        <div class="section">
          <div class="section-title">智能落點分析總結</div>
          ${analysisReportHtml}
        </div>

        <div class="section">
          <div class="section-title">精選推薦學校清單 (依序位評估)</div>
          ${schoolsHtml}
        </div>

        <div class="footer">
          <div class="report-disclaimer">
            <div class="report-disclaimer-label">&#12304;&#31995;&#32113;&#20813;&#36012;&#32882;&#26126;&#12305;</div>
            <p class="report-disclaimer-copy">&#26412;&#31995;&#32113;&#20998;&#26512;&#32080;&#26524;&#20677;&#20379;&#21443;&#32771;&#65292;&#19981;&#20195;&#34920;&#23526;&#38555;&#37636;&#21462;&#32080;&#26524;&#12290;&#23526;&#38555;&#37636;&#21462;&#24773;&#27841;&#21487;&#33021;&#26371;&#22240;&#30070;&#24180;&#24230;&#25307;&#29983;&#25919;&#31574;&#35722;&#21270;&#12289;&#32771;&#29983;&#25972;&#39636;&#34920;&#29694;&#12289;&#29305;&#31278;&#36523;&#20998;&#21152;&#20998;&#12289;&#21508;&#26657;&#25307;&#29983;&#21517;&#38989;&#35519;&#25972;&#31561;&#22240;&#32032;&#32780;&#26377;&#25152;&#19981;&#21516;&#12290;&#35531;&#21209;&#24517;&#20197;&#21508;&#26657;&#26368;&#26032;&#23448;&#26041;&#30332;&#24067;&#20043;&#12300;&#20813;&#35430;&#20837;&#23416;&#25307;&#29983;&#31777;&#31456;&#12301;&#28858;&#26368;&#32066;&#20381;&#25818;&#12290;</p>
            <div class="report-disclaimer-meta"><strong>&#84;&#87;&#20840;&#22283;&#26371;&#32771;&#33853;&#40670;&#20998;&#26512;&#24341;&#25806; &copy; 2026</strong><span>&#38750;&#25919;&#24220;&#23448;&#26041;&#27231;&#27083;</span><span>|</span><a href="${currentUrl}">${currentUrl}</a></div>
          </div>
          <p><strong>【系統免責聲明】</strong> 本系統分析結果僅供參考，不代表實際錄取結果。實際錄取情況可能會因當年度招生政策變化、<br/>考生整體表現、特種身分加分、各校招生名額調整等因素而有所不同。請務必以各校最新官方發布之「免試入學招生簡章」為最終依據。</p>
          <p>TW全國會考落點分析引擎 © ${new Date().getFullYear()} (非政府官方機構) | <a href="${currentUrl}" style="color: #3b82f6; text-decoration: none;">點此返回網站</a></p>
        </div>
        </div>
      </div>
    </body>
    </html>
  `;

  printWindow.document.open();
  printWindow.document.write(html);
  printWindow.document.close();

  const print = () => {
    if (!printWindow.closed) {
      printWindow.focus();
      printWindow.print();
    }
  };
  printWindow.document.querySelector<HTMLButtonElement>('.btn-print')?.addEventListener('click', print);
  // Allow the document and its QR image a moment to paint before opening the
  // native dialog, without relying on CSP-blocked inline popup scripts.
  window.setTimeout(print, 500);
};

export const printSchoolTypes = () => {
  const printWindow = window.open('', '_blank');
  if (!printWindow) {
    alert('無法開啟列印視窗，請檢查是否被瀏覽器阻擋。');
    return;
  }

  const currentDate = new Date().toLocaleString('zh-TW');
  const rawCurrentUrl = window.location.href;
  // Keep the raw URL for QR encoding, but never interpolate it into popup HTML.
  const currentUrl = escapeHtml(rawCurrentUrl);
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=${encodeURIComponent(rawCurrentUrl)}`;

  const html = `
    <!DOCTYPE html>
    <html lang="zh-TW">
    <head>
      <meta charset="UTF-8">
      <title>學校類型解析 - TW全國會考落點分析</title>
      <style>
        @page {
          size: A4;
          margin: 10mm;
        }
        body {
          font-family: "PingFang TC", "Hiragino Sans GB", "Microsoft JhengHei", "Helvetica Neue", Helvetica, Arial, sans-serif;
          margin: 0;
          padding: 0;
          color: #0f172a;
          background: #f8fafc;
          font-size: 11px;
          line-height: 1.3;
        }
        .print-container {
          max-width: 100%;
          margin: 0 auto;
          background: #ffffff;
          padding: 0;
        }
        .header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 12px;
          padding-bottom: 8px;
          border-bottom: 2px solid #0f172a;
        }
        .header-left h1 {
          font-size: 20px;
          font-weight: 900;
          margin: 0 0 4px 0;
          color: #0f172a;
          text-align: left;
        }
        .header-left p {
          color: #64748b;
          font-size: 11px;
          margin: 0;
          text-align: left;
        }
        .header-right {
          text-align: center;
          display: flex;
          flex-direction: column;
          align-items: flex-end;
        }
        .qr-box {
          background: #fff;
          padding: 4px;
          border: 1px solid #e2e8f0;
          border-radius: 4px;
          display: inline-block;
        }
        .qr-box img {
          width: 44px;
          height: 44px;
          display: block;
        }
        .site-link {
          font-size: 9px;
          color: #64748b;
          margin-top: 4px;
          max-width: 120px;
          word-break: break-all;
          line-height: 1.2;
          text-align: right;
        }
        
        .section-title {
          font-size: 14px;
          font-weight: 900;
          color: #0f172a;
          margin-top: 12px;
          margin-bottom: 8px;
          padding-left: 8px;
          border-left: 4px solid #3b82f6;
        }
        
        :root { --print-table-grid: #94a3b8; }
        table {
          width: 100%;
          border-collapse: collapse;
          margin-bottom: 12px;
          border: 1px solid var(--print-table-grid);
        }
        th, td {
          border: 1px solid var(--print-table-grid);
          padding: 4px 8px;
          text-align: left;
        }
        th {
          background-color: #f1f5f9;
          font-weight: 800;
          color: #0f172a;
        }
        td {
          font-weight: 600;
          color: #334155;
        }
        
        .card-grid {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 12px;
          margin-bottom: 16px;
        }
        
        .card {
          border: 1px solid #0f172a;
          border-radius: 8px;
          padding: 10px;
          break-inside: avoid;
        }
        .card h3 {
          font-size: 13px;
          font-weight: 900;
          margin-top: 0;
          margin-bottom: 6px;
          padding-bottom: 4px;
          border-bottom: 1px solid #e2e8f0;
        }
        .card p {
          margin-bottom: 4px;
          font-weight: 600;
        }
        .card p strong {
          color: #0f172a;
          font-weight: 900;
          margin-right: 4px;
        }
        
        .card-full {
          grid-column: 1 / -1;
        }
        
        ul, ol {
          margin-top: 2px;
          margin-bottom: 2px;
          padding-left: 18px;
        }
        li {
          margin-bottom: 2px;
        }
        
        .school-pt { border-color: #10b981; background: #ecfdf5; }
        .school-pt h3 { color: #047857; border-color: #a7f3d0; }
        
        .school-zh { border-color: #0ea5e9; background: #f0f9ff; }
        .school-zh h3 { color: #0369a1; border-color: #bae6fd; }
        
        .school-js { border-color: #f59e0b; background: #fffbeb; }
        .school-js h3 { color: #b45309; border-color: #fde68a; }
        
        .school-dk { border-color: #f43f5e; background: #fff1f2; }
        .school-dk h3 { color: #be123c; border-color: #fecdd3; }
        
        .school-wz { border-color: #a855f7; background: #faf5ff; }
        .school-wz h3 { color: #7e22ce; border-color: #e9d5ff; }

        .flex-tables {
          display: flex;
          gap: 16px;
          align-items: flex-start;
        }
        
        .flex-tables > div {
          flex: 1;
        }

        @media print {
          body { background: white; }
          .print-container { padding: 0; max-width: 100%; border: none; box-shadow: none; }
          .card { border-width: 1px; }
        }
      </style>
    </head>
    <body>
      <div class="print-container">
        <div class="header">
          <div class="header-left">
            <h1>學校類型解析指南</h1>
            <p>列印日期：${currentDate} | TW全國會考落點分析系統</p>
          </div>
          <div class="header-right">
            <div class="qr-box">
              <img src="${qrCodeUrl}" alt="QR Code" />
            </div>
            <div class="site-link">掃描查看原網站<br/>${currentUrl}</div>
          </div>
        </div>

        <div class="section-title">綜合比較表</div>
        <table>
          <thead>
            <tr>
              <th>類型</th>
              <th>就讀年份</th>
              <th>課程特色</th>
              <th>適合學生</th>
              <th>畢業出路</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td style="color: #047857; font-weight: 800;">普通型高中</td>
              <td>3</td>
              <td>學科為主，重視通識與基礎學科</td>
              <td>想升大學、探索學術領域</td>
              <td>大學或科技大學</td>
            </tr>
            <tr>
              <td style="color: #0369a1; font-weight: 800;">綜合型高中</td>
              <td>3</td>
              <td>學科＋專業技能＋實習</td>
              <td>對專業技能有興趣</td>
              <td>就業、科技大學、專科</td>
            </tr>
            <tr>
              <td style="color: #b45309; font-weight: 800;">技術型高中</td>
              <td>3</td>
              <td>普通＋技術並行，提供探索</td>
              <td>尚未確定方向，邊學邊試</td>
              <td>大學、專科、就業</td>
            </tr>
            <tr>
              <td style="color: #be123c; font-weight: 800;">單科型高中</td>
              <td>3</td>
              <td>專注特定領域（如體育、藝術、科學）</td>
              <td>有明確專長或天賦</td>
              <td>升讀相關科系或專長發展</td>
            </tr>
            <tr>
              <td style="color: #7e22ce; font-weight: 800;">五專</td>
              <td>5</td>
              <td>五年一貫，專業銜接完整</td>
              <td>已確定專業興趣</td>
              <td>就業、二技、大學</td>
            </tr>
          </tbody>
        </table>

        <div class="section-title">四種類型詳細解析</div>
        <div class="card-grid">
          <div class="card school-pt">
            <h3>普通型高中 (就讀3年)</h3>
            <p><strong>適合:</strong> 對學術研究有濃厚興趣、尚未決定特定職業方向、想持續探索多元學科領域的學生。</p>
            <p><strong>課程:</strong> 以學術知能為核心，強調基礎考科（國/英/數/自然/社會），並搭配通識教育與多元選修。</p>
            <p><strong>出路:</strong> 主要透過學測、分科測驗，升讀<strong>一般大學</strong>。</p>
          </div>
          
          <div class="card school-zh">
            <h3>綜合型高中 (就讀3年)</h3>
            <p><strong>適合:</strong> 畢業前尚未決定要走學術路線或技術路線，希望多一年的時間一邊學習一邊摸索未來的學生。</p>
            <p><strong>課程:</strong> 高一不分流修習基礎科目；高二起依志向，自由選修「學術學程」(偏高)或「專門學程」(偏職)。</p>
            <p><strong>出路:</strong> 可報考學測升讀一般大學，或報考統測升讀科大/專科，也可選擇就業。</p>
          </div>
          
          <div class="card school-js">
            <h3>技術型高中/高職 (就讀3年)</h3>
            <p><strong>適合:</strong> 對特定技術領域已有興趣，喜歡動手實作，希望能提早學習一技之長的學生。</p>
            <p><strong>課程:</strong> 第一年涵蓋共同科目與基礎專業；後兩年著重於進階專業科目與大量實習實作，培養實戰力。</p>
            <p><strong>出路:</strong> 統測為主，升讀科大、專科學校，或憑技能投入職場就業。</p>
          </div>
          
          <div class="card school-dk">
            <h3>單科型高中 (就讀3年)</h3>
            <p><strong>適合:</strong> 已具備極高的專長天賦（如術科頂尖）或非常明確的高度興趣，決心深耕單一領域者。</p>
            <p><strong>課程:</strong> 針對特定領域（如體育/藝術/科學/音樂等）提供高度專業且密集的訓練。</p>
            <p><strong>出路:</strong> 術科考試或保送甄試為主，升學至特定領域相關學系，或成為職業選手/藝術家。</p>
          </div>

          <div class="card school-wz card-full">
            <h3>五專 (五年制專科學校) - 就讀5年</h3>
            <div style="display: flex; gap: 24px;">
              <div style="flex: 1;">
                <p><strong>學制:</strong> 五年一貫(前3年為高中職，後2年專科)，免受升大學階段性考試壓力。</p>
                <p><strong>招生:</strong> 採全國聯合招生，提供優免、聯免、完免等管道。</p>
                <p><strong>課程:</strong> 前段為基礎，後段著重專業實務知能與企業實習。修畢五年課程授予<strong>副學士學位</strong>。</p>
              </div>
              <div style="flex: 1;">
                <p><strong>適合:</strong> 確立興趣（如護理、外語、資訊等），想避開升學考，盡早培養職場能力者。</p>
                <p><strong>就業:</strong> 以一技之長提早進入職場，起薪通常具備優勢。</p>
                <p><strong>升學:</strong> 可報考二技(取得學士)、插考大學轉學考，或畢業滿三年以上可報考研究所。</p>
              </div>
            </div>
          </div>
        </div>

        <div class="flex-tables">
          <div>
            <div class="section-title">高職與高中學程差異比較</div>
            <table>
              <thead>
                <tr>
                  <th style="width: 25%;">項目</th>
                  <th style="width: 37.5%;">高中</th>
                  <th style="width: 37.5%;">高職</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td><strong>課程導向</strong></td>
                  <td>學術基礎知識 (依各校設班群)</td>
                  <td>專門技術實作 (共15個專業群別)</td>
                </tr>
                <tr>
                  <td><strong>考試類型</strong></td>
                  <td>學測、分科</td>
                  <td>學測、統測</td>
                </tr>
                <tr>
                  <td><strong>考試科目</strong></td>
                  <td>
                    <div style="color: #4f46e5; font-weight: 800;">▶ 學測:</div>
                    <p style="margin: 2px 0 6px 0;">國/英/數/社/自</p>
                    <div style="color: #4f46e5; font-weight: 800;">▶ 分科:</div>
                    <p style="margin: 2px 0 0 0;">數甲/物/化/生/歷/地/公</p>
                  </td>
                  <td>
                    <div style="color: #d97706; font-weight: 800;">▶ 學測:</div>
                    <p style="margin: 2px 0 6px 0;">國/英/數/社/自</p>
                    <div style="color: #d97706; font-weight: 800;">▶ 統測: (共20群別)</div>
                    <p style="margin: 2px 0 0 0;">國/英/數/專(一)/專(二)</p>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <div>
            <div class="section-title">升學管道差異</div>
            <table>
              <thead>
                <tr>
                  <th style="width: 25%;">學制</th>
                  <th style="width: 37.5%;">高中</th>
                  <th style="width: 37.5%;">高職</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style="color: #4f46e5; font-weight: 800; font-size: 13px;">大學</td>
                  <td>
                    <ul style="padding-left:14px; margin:0">
                      <li>特殊選才</li>
                      <li>繁星推薦</li>
                      <li>申請入學</li>
                      <li>考試分發</li>
                    </ul>
                  </td>
                  <td>
                    <ul style="padding-left:14px; margin:0">
                      <li>特殊選才</li>
                      <li>申請入學</li>
                      <li>考試分發</li>
                    </ul>
                  </td>
                </tr>
                <tr>
                  <td style="color: #d97706; font-weight: 800; font-size: 13px;">四技<br/>二專</td>
                  <td>
                    <ul style="padding-left:14px; margin:0">
                      <li>特殊選才</li>
                      <li>四技申請入學</li>
                      <li>技優保送/甄審</li>
                    </ul>
                  </td>
                  <td>
                    <ul style="padding-left:14px; margin:0">
                      <li>特殊選才</li>
                      <li>技職繁星</li>
                      <li>四技甄選</li>
                      <li>統測分發</li>
                      <li>技優保送/甄審</li>
                    </ul>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div style="margin-top: 12px; text-align: center; color: #94a3b8; font-size: 10px;">
          <p>本資料表僅供參考，詳情請以官方最新之招生簡章為準。</p>
        </div>
      </div>
      <script>
        window.onload = function() {
          setTimeout(function() {
             window.print();
          }, 500);
        }
      </script>
    </body>
    </html>
  `;

  printWindow.document.open();
  printWindow.document.write(html);
  printWindow.document.close();
};
